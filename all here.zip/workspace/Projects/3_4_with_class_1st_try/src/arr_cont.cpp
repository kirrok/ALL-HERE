#include "arr_cont.h"

arr_cont::arr_cont()
{
    //ctor
}

arr_cont::~arr_cont()
{
    //dtor
}
