#ifndef ARR_CONT_H
#define ARR_CONT_H


class arr_cont
{
    public:
        arr_cont();
        virtual ~arr_cont();
    protected:
    private:
};

#endif // ARR_CONT_H
