/*
Соболев Кирилл.
6_1.

Дано N кубиков. Требуется определить каким количеством способов можно выстроить из этих кубиков
пирамиду.
  ​
Высокая пирамида. ​
Каждый вышележащий слой пирамиды должен быть не больше нижележащего.

*/


#include <iostream>
#include <stdint.h>
#include <stdio.h>


long int  build_tower(int number_of_cubes) {

   long int table[number_of_cubes + 1][number_of_cubes + 1] ;
    long int result = 0;


    for (int i = 1; i <= number_of_cubes ; i ++)
        for (int j = 1; j <= number_of_cubes ; j++)
            table[i][j] = 0;


    for (int current_number_of_cubes = 1; current_number_of_cubes <= number_of_cubes; current_number_of_cubes++ ) {

        for (int number_of_floors = 1 ; number_of_floors <= current_number_of_cubes; number_of_floors ++ ) {

            int cubes_left = current_number_of_cubes - number_of_floors;

            if (cubes_left == 0 || number_of_floors == 1)
                table[current_number_of_cubes][number_of_floors] = 1;

            else
                for (int i = 1 ; i <= cubes_left && i <= number_of_floors; i++)
                    table[current_number_of_cubes][number_of_floors] += table[cubes_left][i];

        }

    }

    for (int i = 1; i <= number_of_cubes;i++)
        result += table[number_of_cubes][i];

    return result;
}


int main () {

    int number_of_cubes;

    std::cin >> number_of_cubes;

    std::cout << build_tower(number_of_cubes);

    return 0;
}
