#include <iostream>

using namespace std;

int main() {

int m = 19&1;
    cout << m << endl;
    return 0;
}
