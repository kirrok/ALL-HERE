#ifndef CSTACK_H
#define CSTACK_H


class cstack
{
    public:
        cstack();
        virtual ~cstack();
    protected:
    private:
};

#endif // CSTACK_H
