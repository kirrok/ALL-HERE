#include "cstack.h"

cstack::cstack()
{
    //ctor
}

cstack::~cstack()
{
    //dtor
}
