#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 10;
    printf("Hello world!\n%d",i);
    return 0;
}
